$inputFile = ".\input.csv"
$startIndex = 5
$endIndex = 10
$dstSiteUrl = "https://your.sharepoint.com/sites/20190101/targetsite"
